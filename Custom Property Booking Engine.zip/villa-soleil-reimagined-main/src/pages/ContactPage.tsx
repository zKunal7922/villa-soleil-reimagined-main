import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import ContactSection from "@/components/ContactSection";

const ContactPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Contact Section */}
      <section className="pt-24 py-16">
        <div className="container mx-auto max-w-6xl px-6">
          <ContactSection />
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ContactPage;