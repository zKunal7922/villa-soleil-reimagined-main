import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import AmenitiesSection from "@/components/AmenitiesSection";

const AmenitiesPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Amenities Section */}
      <section className="pt-24 py-16">
        <div className="container mx-auto max-w-6xl px-6">
          <AmenitiesSection />
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default AmenitiesPage;