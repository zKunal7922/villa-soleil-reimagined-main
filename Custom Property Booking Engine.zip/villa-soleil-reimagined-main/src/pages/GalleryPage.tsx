import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import ImageGallery from "@/components/ImageGallery";

const GalleryPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Gallery Section */}
      <section className="pt-24 py-16">
        <div className="container mx-auto max-w-6xl px-6">
          <ImageGallery />
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default GalleryPage;