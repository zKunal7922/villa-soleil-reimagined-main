// Villa Soleil - Luxury Vacation Rental Website

import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import HighlightsSection from "@/components/HighlightsSection";
import ImageGallery from "@/components/ImageGallery";
import AboutSection from "@/components/AboutSection";
import AmenitiesSection from "@/components/AmenitiesSection";
import LocationSection from "@/components/LocationSection";
import ReviewsSection from "@/components/ReviewsSection";
import BookingSection from "@/components/BookingSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      
      <main>
        <section id="home">
          <HeroSection />
        </section>
        
        <section id="about">
          <AboutSection />
        </section>
        
        <section id="gallery">
          <ImageGallery />
        </section>
        
        <section id="amenities">
          <AmenitiesSection />
        </section>
        
        <section id="location">
          <LocationSection />
        </section>
        
        <HighlightsSection />
        
        <section id="reviews">
          <ReviewsSection />
        </section>
        
        <section id="booking">
          <BookingSection />
        </section>
        
        <section id="contact">
          <ContactSection />
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
