import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Calendar as CalendarIcon, ArrowLeft, Users, MapPin, Clock, Car, ChefHat, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

const BookingPage = () => {
  const navigate = useNavigate();
  const [checkIn, setCheckIn] = useState<Date>();
  const [checkOut, setCheckOut] = useState<Date>();
  const [guests, setGuests] = useState("2");
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    specialRequests: ""
  });

  const [selectedUpsells, setSelectedUpsells] = useState<string[]>([]);

  const upsellOptions = [
    {
      id: "early-checkin",
      title: "Early Check-in (12:00 PM)",
      description: "Check in 4 hours earlier than standard time",
      price: 150,
      icon: Clock
    },
    {
      id: "late-checkout", 
      title: "Late Check-out (2:00 PM)",
      description: "Enjoy 4 extra hours on your departure day",
      price: 150,
      icon: Clock
    },
    {
      id: "airport-transfer",
      title: "Private Airport Transfer",
      description: "Luxury vehicle pickup and drop-off service",
      price: 250,
      icon: Car
    },
    {
      id: "chef-service",
      title: "Private Chef Service",
      description: "Professional chef for one evening (up to 8 guests)",
      price: 800,
      icon: ChefHat
    },
    {
      id: "grocery-stocking",
      title: "Pre-Arrival Grocery Stocking",
      description: "Fresh groceries and essentials ready upon arrival",
      price: 200,
      icon: Sparkles
    },
    {
      id: "spa-service",
      title: "In-Villa Spa Treatment",
      description: "Relaxing massage therapy session for 2 guests",
      price: 400,
      icon: Sparkles
    }
  ];

  const handleUpsellToggle = (upsellId: string) => {
    setSelectedUpsells(prev => 
      prev.includes(upsellId) 
        ? prev.filter(id => id !== upsellId)
        : [...prev, upsellId]
    );
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const calculateNights = () => {
    if (checkIn && checkOut) {
      const diffTime = Math.abs(checkOut.getTime() - checkIn.getTime());
      return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }
    return 0;
  };

  const calculateTotal = () => {
    const nights = calculateNights();
    const guestCount = parseInt(guests);
    
    // Base price is $749 for up to 4 guests
    let nightlyRate = 749;
    
    // Add $100 per guest above 4
    if (guestCount > 4) {
      nightlyRate += (guestCount - 4) * 100;
    }
    
    const basePrice = nights * nightlyRate;
    const upsellsTotal = selectedUpsells.reduce((total, upsellId) => {
      const upsell = upsellOptions.find(u => u.id === upsellId);
      return total + (upsell?.price || 0);
    }, 0);
    const cleaningFee = 200;
    const subtotal = basePrice + upsellsTotal + cleaningFee;
    return {
      nights,
      nightlyRate,
      basePrice,
      upsellsTotal,
      cleaningFee,
      total: subtotal
    };
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!checkIn || !checkOut) {
      toast({
        title: "Please select dates",
        description: "Both check-in and check-out dates are required.",
        variant: "destructive"
      });
      return;
    }

    if (!formData.firstName || !formData.lastName || !formData.email) {
      toast({
        title: "Please fill required fields",
        description: "Name and email are required to complete your booking.",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Booking Request Submitted!",
      description: "We'll send you a confirmation email shortly with payment details.",
    });
  };

  const pricing = calculateTotal();

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="pt-20">
        <div className="max-w-6xl mx-auto px-6 py-12">
          
          {/* Header */}
          <div className="mb-8">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/property')} 
              className="mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Property
            </Button>
            
            <h1 className="text-3xl font-bold mb-2">Complete Your Booking</h1>
            <div className="flex items-center gap-4 text-muted-foreground">
              <div className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                <span>Villa Soleil, Saint-Barthélemy</span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                <span>Up to 11 guests</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            
            {/* Left Column - Booking Form */}
            <div className="space-y-8">
              
              {/* Dates Selection */}
              <Card>
                <CardHeader>
                  <CardTitle>Select Your Dates</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Check-in Date</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !checkIn && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {checkIn ? format(checkIn, "PPP") : "Select date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={checkIn}
                            onSelect={setCheckIn}
                            initialFocus
                            disabled={(date) => date < new Date()}
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Check-out Date</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !checkOut && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {checkOut ? format(checkOut, "PPP") : "Select date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={checkOut}
                            onSelect={setCheckOut}
                            initialFocus
                            disabled={(date) => date < new Date() || (checkIn && date <= checkIn)}
                            className="pointer-events-auto"
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Number of Guests</Label>
                    <Select value={guests} onValueChange={setGuests}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select number of guests" />
                      </SelectTrigger>
                      <SelectContent>
                        {[1,2,3,4,5,6,7,8,9,10,11].map(num => (
                          <SelectItem key={num} value={num.toString()}>
                            {num} {num === 1 ? 'Guest' : 'Guests'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* Enhanced Experience Add-ons */}
              <Card>
                <CardHeader>
                  <CardTitle>Enhanced Experience Add-ons</CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Make your stay even more memorable with our premium services
                  </p>
                </CardHeader>
                <CardContent className="space-y-4">
                  {upsellOptions.map((upsell) => {
                    const IconComponent = upsell.icon;
                    const isSelected = selectedUpsells.includes(upsell.id);
                    
                    return (
                      <div
                        key={upsell.id}
                        className={cn(
                          "flex items-start space-x-4 p-4 rounded-lg border cursor-pointer transition-all",
                          isSelected 
                            ? "border-primary bg-primary/5" 
                            : "border-border hover:border-primary/50"
                        )}
                        onClick={() => handleUpsellToggle(upsell.id)}
                      >
                        <Checkbox 
                          checked={isSelected}
                          onChange={() => handleUpsellToggle(upsell.id)}
                          className="mt-1"
                        />
                        <IconComponent className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium text-foreground">{upsell.title}</h4>
                            <span className="text-sm font-semibold text-primary">
                              +${upsell.price}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            {upsell.description}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>

              {/* Guest Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Guest Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name *</Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => handleInputChange("firstName", e.target.value)}
                        placeholder="Enter first name"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name *</Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => handleInputChange("lastName", e.target.value)}
                        placeholder="Enter last name"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      placeholder="Enter email address"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      placeholder="Enter phone number"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="specialRequests">Special Requests</Label>
                    <Textarea
                      id="specialRequests"
                      value={formData.specialRequests}
                      onChange={(e) => handleInputChange("specialRequests", e.target.value)}
                      placeholder="Any special requests or notes..."
                      rows={3}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Booking Summary */}
            <div>
              <div className="sticky top-24">
                <Card className="shadow-luxury">
                  <CardHeader>
                    <CardTitle>Booking Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    
                    {/* Property Details */}
                    <div className="space-y-2">
                      <h3 className="font-semibold">Villa Soleil</h3>
                      <p className="text-sm text-muted-foreground">
                        Luxury Beachfront Villa
                      </p>
                    </div>
                    
                    <Separator />
                    
                    {/* Date Summary */}
                    {checkIn && checkOut && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Check-in:</span>
                          <span>{format(checkIn, "MMM dd, yyyy")}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Check-out:</span>
                          <span>{format(checkOut, "MMM dd, yyyy")}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Guests:</span>
                          <span>{guests}</span>
                        </div>
                      </div>
                    )}
                    
                    <Separator />
                    
                    {/* Pricing Breakdown */}
                    {pricing.nights > 0 && (
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span>${pricing.nightlyRate} x {pricing.nights} nights</span>
                          <span>${pricing.basePrice.toLocaleString()}</span>
                        </div>
                         {pricing.upsellsTotal > 0 && (
                           <div className="flex justify-between">
                             <span>Add-on services</span>
                             <span>${pricing.upsellsTotal.toLocaleString()}</span>
                           </div>
                         )}
                         <div className="flex justify-between">
                           <span>Cleaning fee</span>
                           <span>${pricing.cleaningFee.toLocaleString()}</span>
                         </div>
                        <Separator />
                        <div className="flex justify-between font-semibold text-lg">
                          <span>Total</span>
                          <span>${pricing.total.toLocaleString()}</span>
                        </div>
                      </div>
                    )}
                    
                    <Button 
                      size="lg" 
                      className="w-full"
                      onClick={handleSubmit}
                      disabled={!checkIn || !checkOut}
                    >
                      Complete Booking
                    </Button>
                    
                    <p className="text-xs text-center text-muted-foreground">
                      You won't be charged until the booking is confirmed
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default BookingPage;