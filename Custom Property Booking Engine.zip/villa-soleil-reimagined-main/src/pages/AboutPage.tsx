import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import AboutSection from "@/components/AboutSection";

const AboutPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* About Section */}
      <section className="pt-24 py-16">
        <div className="container mx-auto max-w-6xl px-6">
          <AboutSection />
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default AboutPage;