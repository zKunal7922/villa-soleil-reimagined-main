import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  MapPin, 
  Users, 
  Bed, 
  Bath, 
  Wifi, 
  Car, 
  Utensils, 
  Waves,
  Star,
  Shield,
  Home
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import heroImage from "@/assets/villa-hero.jpg";
import interiorImage from "@/assets/villa-interior.jpg";
import bedroomImage from "@/assets/villa-bedroom.jpg";
import poolImage from "@/assets/villa-pool.jpg";

const PropertyPage = () => {
  const navigate = useNavigate();

  const amenities = [
    { icon: Wifi, label: "High-Speed WiFi" },
    { icon: Car, label: "Free Parking" },
    { icon: Utensils, label: "Full Kitchen" },
    { icon: Waves, label: "Private Pool" },
    { icon: Home, label: "Luxury Interior" },
    { icon: Shield, label: "24/7 Security" }
  ];

  const images = [
    { src: heroImage, alt: "Villa Soleil exterior view" },
    { src: interiorImage, alt: "Luxury living area" },
    { src: bedroomImage, alt: "Master bedroom" },
    { src: poolImage, alt: "Private pool area" }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <main className="pt-20">
        {/* Hero Image Gallery */}
        <section className="relative">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2 max-w-7xl mx-auto px-6">
            {images.map((image, index) => (
              <div 
                key={index} 
                className={`relative overflow-hidden rounded-lg ${
                  index === 0 ? 'md:col-span-2 lg:col-span-2 h-96' : 'h-48'
                }`}
              >
                <img 
                  src={image.src} 
                  alt={image.alt}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            ))}
          </div>
        </section>

        {/* Property Details */}
        <section className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            {/* Left Column - Property Info */}
            <div className="lg:col-span-2 space-y-8">
              
              {/* Header */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="bg-accent/20">
                    <Star className="w-3 h-3 mr-1" />
                    Superhost
                  </Badge>
                  <Badge variant="outline">CITQ: 307481</Badge>
                </div>
                
                <h1 className="text-4xl font-bold text-foreground">
                  Villa Soleil - Luxury Beachfront Escape
                </h1>
                
                <div className="flex items-center gap-4 text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    <span>Saint-Barthélemy, Caribbean</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    <span>8 guests</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Bed className="w-4 h-4" />
                    <span>4 bedrooms</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Bath className="w-4 h-4" />
                    <span>3 bathrooms</span>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Description */}
              <div className="space-y-4">
                <h2 className="text-2xl font-semibold">About Villa Soleil</h2>
                <div className="prose prose-lg max-w-none text-muted-foreground">
                  <p>
                    Welcome to Villa Soleil, a breathtaking luxury beachfront villa that epitomizes 
                    Caribbean elegance and tropical sophistication. Perched on the pristine shores 
                    of Saint-Barthélemy, this magnificent property offers an unparalleled vacation 
                    experience with stunning ocean views and world-class amenities.
                  </p>
                  <p>
                    As you step inside, you'll be greeted by an open-concept living space that 
                    seamlessly blends indoor and outdoor living. The villa features four beautifully 
                    appointed bedrooms, each with en-suite bathrooms and private terraces overlooking 
                    the turquoise waters of the Caribbean Sea.
                  </p>
                  <p>
                    The heart of the villa is the expansive living area, complete with a gourmet 
                    kitchen, elegant dining space, and comfortable lounge areas. Floor-to-ceiling 
                    windows flood the space with natural light and provide breathtaking panoramic 
                    views of the ocean and surrounding tropical landscape.
                  </p>
                </div>
              </div>

              <Separator />

              {/* Amenities */}
              <div className="space-y-4">
                <h2 className="text-2xl font-semibold">Amenities</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {amenities.map((amenity, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <amenity.icon className="w-5 h-5 text-primary" />
                      <span className="text-sm">{amenity.label}</span>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              {/* Reviews */}
              <div className="space-y-6">
                <h2 className="text-2xl font-semibold">Guest Reviews</h2>
                <div className="grid gap-6">
                  {[
                    {
                      name: "Sarah M.",
                      review: "Perfect location and beautifully furnished villa. The ocean views are absolutely stunning!",
                      rating: 5
                    },
                    {
                      name: "David L.", 
                      review: "Luxury at its finest. The private pool and beach access made our stay unforgettable.",
                      rating: 5
                    },
                    {
                      name: "Marie C.",
                      review: "Exceptional property with world-class amenities. Would definitely stay again!",
                      rating: 5
                    }
                  ].map((review, index) => (
                    <Card key={index}>
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 rounded-full bg-accent flex items-center justify-center">
                            <span className="font-semibold text-accent-foreground">
                              {review.name.charAt(0)}
                            </span>
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <span className="font-semibold">{review.name}</span>
                              <div className="flex">
                                {[...Array(review.rating)].map((_, i) => (
                                  <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                                ))}
                              </div>
                            </div>
                            <p className="text-muted-foreground">{review.review}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column - Booking Card */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <Card className="shadow-luxury">
                  <CardContent className="p-6 space-y-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-primary">$850</div>
                      <div className="text-sm text-muted-foreground">per night</div>
                    </div>
                    
                    <Button 
                      size="lg" 
                      className="w-full"
                      onClick={() => navigate('/booking')}
                    >
                      Reserve Now
                    </Button>
                    
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span>$850 x 7 nights</span>
                        <span>$5,950</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Service fee</span>
                        <span>$297</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Taxes</span>
                        <span>$178</span>
                      </div>
                      <Separator />
                      <div className="flex justify-between font-semibold">
                        <span>Total</span>
                        <span>$6,425</span>
                      </div>
                    </div>
                    
                    <div className="text-xs text-center text-muted-foreground">
                      You won't be charged yet
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default PropertyPage;