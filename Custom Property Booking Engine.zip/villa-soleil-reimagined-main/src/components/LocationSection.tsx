import { MapPin, Navigation, Clock } from "lucide-react";

const nearbyAttractions = [
  { name: "Pristine Beach", distance: "2 min walk", icon: Navigation },
  { name: "Marina & Restaurants", distance: "5 min drive", icon: MapPin },
  { name: "Golf Course", distance: "10 min drive", icon: Clock },
  { name: "Airport", distance: "25 min drive", icon: Navigation },
];

const LocationSection = () => {
  return (
    <section className="py-20 px-6 bg-luxury-cream">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 luxury-text-gradient">
            Perfect Location
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Ideally situated for both relaxation and exploration
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Map Placeholder */}
          <div className="relative">
            <div className="aspect-video bg-gradient-to-br from-tropical-blue to-ocean-deep rounded-2xl shadow-2xl flex items-center justify-center">
              <div className="text-center text-white">
                <MapPin className="w-16 h-16 mx-auto mb-4" />
                <p className="text-lg font-semibold">Interactive Map</p>
                <p className="text-sm opacity-90">Premium Location Overlay</p>
              </div>
            </div>
          </div>

          {/* Nearby Attractions */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-foreground mb-8">
              Nearby Attractions
            </h3>
            {nearbyAttractions.map((attraction, index) => (
              <div key={index} className="flex items-center space-x-4 p-4 card-luxury rounded-xl hover:transform hover:scale-105 transition-all duration-300">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                  <attraction.icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold text-foreground">{attraction.name}</h4>
                  <p className="text-muted-foreground">{attraction.distance}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default LocationSection;