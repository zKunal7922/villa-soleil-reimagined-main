import { Star } from "lucide-react";

const reviews = [
  {
    name: "Sarah Johnson",
    location: "New York, USA",
    rating: 5,
    comment: "Absolutely stunning villa! The ocean views were breathtaking and the amenities exceeded our expectations. Perfect for our anniversary celebration.",
    date: "March 2024"
  },
  {
    name: "Marcus Chen",
    location: "London, UK",
    rating: 5,
    comment: "Villa Soleil provided the perfect escape. The private pool and luxury interiors made our family vacation unforgettable. Highly recommended!",
    date: "February 2024"
  },
  {
    name: "Isabella Rodriguez",
    location: "Barcelona, Spain",
    rating: 5,
    comment: "A true paradise! The attention to detail and concierge service were exceptional. We'll definitely be returning next year.",
    date: "January 2024"
  }
];

const ReviewsSection = () => {
  return (
    <section className="py-20 px-6 bg-background">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 luxury-text-gradient">
            Guest Reviews
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Hear what our guests have to say about their Villa Soleil experience
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="card-luxury rounded-2xl p-8 hover:transform hover:scale-105 transition-all duration-300">
              {/* Rating Stars */}
              <div className="flex items-center mb-4">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-primary fill-current" />
                ))}
              </div>
              
              {/* Review Text */}
              <p className="text-muted-foreground mb-6 italic">
                "{review.comment}"
              </p>
              
              {/* Reviewer Info */}
              <div className="border-t border-border pt-4">
                <h4 className="font-semibold text-foreground">{review.name}</h4>
                <p className="text-sm text-muted-foreground">{review.location}</p>
                <p className="text-xs text-muted-foreground mt-1">{review.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ReviewsSection;