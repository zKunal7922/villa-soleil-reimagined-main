import { 
  Wifi, 
  Car, 
  ChefHat, 
  Snowflake, 
  Tv, 
  Waves, 
  Dumbbell, 
  Coffee,
  Shield,
  Users,
  Utensils,
  Bath
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";

const amenities = [
  { icon: Wifi, label: "High-Speed WiFi" },
  { icon: Snowflake, label: "Air Conditioning" },
  { icon: Car, label: "Private Parking" },
  { icon: ChefHat, label: "Gourmet Kitchen" },
  { icon: Waves, label: "Private Pool" },
  { icon: Tv, label: "Smart TV" },
  { icon: Dumbbell, label: "Fitness Area" },
  { icon: Coffee, label: "Coffee Machine" },
  { icon: Shield, label: "24/7 Security" },
  { icon: Users, label: "Concierge Service" },
  { icon: Utensils, label: "BBQ Grill" },
  { icon: Bath, label: "Luxury Bathrooms" },
];

const AmenitiesSection = () => {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkScreenSize();
    window.addEventListener('resize', checkScreenSize);
    
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  const displayedAmenities = isMobile ? amenities.slice(0, 6) : amenities;

  return (
    <section className="py-20 px-6 bg-background">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 luxury-text-gradient">
            Premium Amenities
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Every detail has been thoughtfully curated to ensure your complete comfort and luxury
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {displayedAmenities.map((amenity, index) => (
            <div 
              key={index} 
              className="card-luxury rounded-xl p-6 text-center group hover:transform hover:scale-105 transition-all duration-300"
            >
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                <amenity.icon className="w-6 h-6 text-primary" />
              </div>
              <p className="text-sm font-medium text-foreground">
                {amenity.label}
              </p>
            </div>
          ))}
        </div>
        
        {/* Learn More Button for Mobile */}
        <div className="text-center mt-8 md:hidden">
          <Link to="/amenities">
            <Button variant="luxury" size="lg">
              View All Amenities
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default AmenitiesSection;