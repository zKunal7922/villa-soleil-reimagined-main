import { MapPin, Waves, Sparkles, Camera } from "lucide-react";
import villaPool from "@/assets/villa-pool.jpg";
import villaHero from "@/assets/villa-hero.jpg";
import villaInterior from "@/assets/villa-interior.jpg";
import villaBedroom from "@/assets/villa-bedroom.jpg";

const highlights = [
  {
    icon: Waves,
    title: "Private Pool",
    description: "Infinity pool with stunning ocean views",
    image: villaPool
  },
  {
    icon: MapPin,
    title: "Ocean View",
    description: "Panoramic views of the crystal-clear waters",
    image: villaHero
  },
  {
    icon: Sparkles,
    title: "Luxury Interiors",
    description: "Premium furnishings and modern amenities",
    image: villaInterior
  },
  {
    icon: Camera,
    title: "Nearby Attractions",
    description: "Close to beaches, restaurants, and activities",
    image: villaBedroom
  }
];

const HighlightsSection = () => {
  return (
    <section className="py-20 px-6 bg-gradient-to-b from-background to-luxury-cream">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 luxury-text-gradient">
            Villa Highlights
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover what makes Villa Soleil the perfect destination for your luxury getaway
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {highlights.map((highlight, index) => (
            <div key={index} className="text-center group">
              <div className="card-luxury rounded-2xl overflow-hidden transition-all duration-300 hover:transform hover:scale-105">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={highlight.image} 
                    alt={highlight.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/20 transition-opacity duration-300 group-hover:bg-black/10" />
                </div>
                <div className="p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                    <highlight.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3 text-foreground">
                    {highlight.title}
                  </h3>
                  <p className="text-muted-foreground">
                    {highlight.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HighlightsSection;