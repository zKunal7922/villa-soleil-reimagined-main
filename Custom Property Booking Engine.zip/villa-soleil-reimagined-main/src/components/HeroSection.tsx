import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import heroImage from "@/assets/villa-hero.jpg";
import villaPool from "@/assets/villa-pool.jpg";
import villaInterior from "@/assets/villa-interior.jpg";

const HeroSection = () => {
  const images = [heroImage, villaPool, villaInterior];
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => 
        prevIndex === images.length - 1 ? 0 : prevIndex + 1
      );
    }, 3000); // Change image every 3 seconds

    return () => clearInterval(interval);
  }, [images.length]);

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Photo Collage Background */}
      {images.map((image, index) => (
        <div
          key={index}
          className={`absolute inset-0 bg-cover bg-center bg-no-repeat transition-opacity duration-1000 ${
            index === currentImageIndex ? 'opacity-100' : 'opacity-0'
          }`}
          style={{ 
            backgroundImage: `url(${image})`,
            transform: 'translateX(-2px) translateY(-1px)'
          }}
        />
      ))}
      
      {/* Subtle dark overlay for text readability */}
      <div className="absolute inset-0 bg-black/20" />
      
      {/* Content */}
      <div className="relative z-10 text-center text-white px-6 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 luxury-text-gradient">
          Villa Soleil
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-2xl mx-auto">
          Experience luxury and tranquility in our stunning oceanfront villa with private pool and breathtaking views
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button variant="hero" size="xl" className="min-w-48" asChild>
            <a href="/booking">Book Now</a>
          </Button>
          <Button variant="outline" size="xl" className="min-w-48 border-white/60 bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm" asChild>
            <a href="/property">View Property</a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;