import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

import heroImage from "@/assets/villa-hero.jpg";
import interiorImage from "@/assets/villa-interior.jpg";
import bedroomImage from "@/assets/villa-bedroom.jpg";
import poolImage from "@/assets/villa-pool.jpg";

const images = [
  { src: heroImage, alt: "Villa Soleil Exterior" },
  { src: interiorImage, alt: "Luxury Living Room" },
  { src: bedroomImage, alt: "Master Bedroom" },
  { src: poolImage, alt: "Private Pool Area" },
];

const ImageGallery = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextImage = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <section className="py-20 px-6 bg-background">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 luxury-text-gradient">
            Villa Gallery
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Take a virtual tour through our stunning luxury villa
          </p>
        </div>

        {/* Main Image Carousel */}
        <div className="relative mb-8 flex justify-center">
          <div className="aspect-[4/3] md:aspect-video overflow-hidden rounded-2xl shadow-2xl max-h-[500px] w-full max-w-4xl">
            <img
              src={images[currentIndex].src}
              alt={images[currentIndex].alt}
              className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
            />
          </div>
          
          {/* Navigation Buttons */}
          <Button
            variant="secondary"
            size="icon"
            onClick={prevImage}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 w-12 h-12 rounded-full shadow-lg"
          >
            <ChevronLeft className="w-6 h-6" />
          </Button>
          <Button
            variant="secondary"
            size="icon"
            onClick={nextImage}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 w-12 h-12 rounded-full shadow-lg"
          >
            <ChevronRight className="w-6 h-6" />
          </Button>
        </div>

        {/* Thumbnail Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {images.map((image, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`aspect-video overflow-hidden rounded-lg transition-all duration-300 ${
                index === currentIndex
                  ? "ring-4 ring-primary shadow-lg scale-105"
                  : "opacity-70 hover:opacity-100"
              }`}
            >
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ImageGallery;