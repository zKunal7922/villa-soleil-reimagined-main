import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import interiorImage from "@/assets/villa-interior.jpg";

const AboutSection = () => {
  return (
    <section className="py-20 px-6 bg-luxury-cream">
      <div className="container mx-auto max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-6">
            <h2 className="text-4xl md:text-5xl font-bold luxury-text-gradient">
              About Villa Soleil
            </h2>
            <div className="space-y-4 text-lg text-muted-foreground">
              <p>
                Nestled in a pristine tropical paradise, Villa Soleil offers an unparalleled luxury experience 
                with breathtaking ocean views and world-class amenities. This stunning private villa combines 
                modern elegance with tropical charm, creating the perfect sanctuary for your dream vacation.
              </p>
              <p>
                Our spacious villa features premium accommodations for up to 8 guests, with elegantly appointed 
                bedrooms, a gourmet kitchen, and expansive living areas that seamlessly blend indoor and outdoor living. 
                The infinity pool and private terrace provide the ideal setting for relaxation and entertainment.
              </p>
              <p className="hidden md:block">
                Located just minutes from pristine beaches, world-class dining, and exciting local attractions, 
                Villa Soleil offers both serenity and adventure. Whether you're seeking a romantic getaway, 
                family vacation, or celebration with friends, our villa provides the perfect backdrop for 
                unforgettable memories.
              </p>
            </div>
            <Link to="/about">
              <Button variant="luxury" size="lg" className="mt-8" onClick={() => {
                setTimeout(() => window.scrollTo({ top: 0, behavior: 'smooth' }), 100);
              }}>
                Learn More
              </Button>
            </Link>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="aspect-square overflow-hidden rounded-2xl shadow-2xl">
              <img
                src={interiorImage}
                alt="Villa Soleil Interior"
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary/10 rounded-full blur-xl" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;